package kosien.procon.application.matatabidb;

/**
 * Created by procon-kyougi on 2017/09/22.
 */

//必ず記述するもの


abstract public class makeLink {
  //  makeLink(){}
    //APIコード
    protected final String API_CODE = "5746654e35546d624d37486a564631536941446f525472496e647536636c496b7148637969727361474333";
    //クライアントコード
    protected final String CLIENT_CODE = "WxYBozg2IyUCgLt33sQJiTUrtdJTwG7jVfB0ueT173SW";
    //蔵案とシークレット
    protected final String _CODE = "<bc)LX.wSPJ;R2Nzf9=U";
    //リンク取得関数
    abstract public String getSearchLink();

}
